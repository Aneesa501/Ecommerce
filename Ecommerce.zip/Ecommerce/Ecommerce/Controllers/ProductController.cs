﻿using Microsoft.AspNetCore.Mvc;
using Ecommerce.Models;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using System.Text;
using static System.Net.WebRequestMethods;

namespace Ecommerce.Controllers
{
    public class ProductController : Controller
    {
        private string url = "https://localhost:44381/api/Product";
        private HttpClient client = new();

        [HttpGet]
        public IActionResult Index()
        {
            List<Product> products = new();
            HttpResponseMessage response = client.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
            {
                string result=response.Content.ReadAsStringAsync().Result;
                var data=JsonConvert.DeserializeObject<List<Product>>(result);
                if(data!=null)
                {
                    products=data;
                }
            }
            return View(products);
        }
        [HttpGet]
        public IActionResult    Create() 
        { 
           return View();
        }
        [HttpPost]
        public IActionResult Create( Product pro)
        {
            var data=JsonConvert.SerializeObject(pro);
            StringContent content = new(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response=client.PostAsync(url, content).Result; 
            if(response.IsSuccessStatusCode)
            {
                TempData["insert_Message"] = " Product Added..";
                return RedirectToAction("index");
            }
            return View();
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Product pro=new();
            HttpResponseMessage response = client.GetAsync(url+id).Result;
            if(response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Product>(result);
                if (data != null)
                {
                    pro = data;
                }
            }

            return View(pro);
        }
        
        [HttpPost]
        public IActionResult Edit(Product pro)
        {
            var data = JsonConvert.SerializeObject(pro);
            StringContent content = new(data, Encoding.UTF8, "application/json");
            HttpResponseMessage response = client.PutAsync(url+pro.prid, content).Result;
            if (response.IsSuccessStatusCode)
            {
                TempData["Update_Message"] = " Product Updated..";
                return RedirectToAction("index");
            }
            return View();
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            Product pro = new Product();
            HttpResponseMessage response=client.GetAsync(url+id).Result;
            if (response.IsSuccessStatusCode) { 
                string result=response.Content.ReadAsStringAsync().Result;
                var data=JsonConvert.DeserializeObject<Product>(result);
                if (data != null) { 
                    pro = data;
                }
            }
            return View(pro);
        }
        [HttpPost ,ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            
            HttpResponseMessage response = client.DeleteAsync(url + id).Result;
            if (response.IsSuccessStatusCode)
            {

                TempData["Delete_Message"] = " Product Updated..";
                return RedirectToAction("index");
            }
            return View();
        }
    }
}
