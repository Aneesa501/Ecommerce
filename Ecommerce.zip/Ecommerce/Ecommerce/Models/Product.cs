﻿using Microsoft.Build.Framework;

namespace Ecommerce.Models
{
        public class Product
        {
            [Required]
            public int prid { get; set; }
            [Required] 
            public string productName { get; set; }
            [Required]
            public float quantity { get; set; }
            [Required]
            public float price { get; set; }
        }

    
}
